﻿namespace _291_Group2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea7 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend7 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series7 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.Customer = new System.Windows.Forms.TabControl();
            this.Customers = new System.Windows.Forms.TabPage();
            this.GetCustomer = new System.Windows.Forms.Button();
            this.PrevCustomer = new System.Windows.Forms.Button();
            this.NextCustomer = new System.Windows.Forms.Button();
            this.Province = new System.Windows.Forms.TextBox();
            this.ProvinceLabel = new System.Windows.Forms.Label();
            this.DeleteCustomer = new System.Windows.Forms.Button();
            this.MembershipG = new System.Windows.Forms.RadioButton();
            this.MembershipS = new System.Windows.Forms.RadioButton();
            this.UpdateCustomer = new System.Windows.Forms.Button();
            this.DOB = new System.Windows.Forms.DateTimePicker();
            this.CreateCustomer = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.CID = new System.Windows.Forms.TextBox();
            this.CustomerIDLabel = new System.Windows.Forms.Label();
            this.DriverLicense = new System.Windows.Forms.TextBox();
            this.DriversLabel = new System.Windows.Forms.Label();
            this.Insurance = new System.Windows.Forms.TextBox();
            this.InsuranceLabel = new System.Windows.Forms.Label();
            this.PhoneNumber = new System.Windows.Forms.TextBox();
            this.PhoneLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.PostalCode = new System.Windows.Forms.TextBox();
            this.PostalCodeLabel = new System.Windows.Forms.Label();
            this.City = new System.Windows.Forms.TextBox();
            this.CityLabel = new System.Windows.Forms.Label();
            this.StreetAddress2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.StreetAddress1 = new System.Windows.Forms.TextBox();
            this.StreetAddressLabel1 = new System.Windows.Forms.Label();
            this.LName = new System.Windows.Forms.TextBox();
            this.LNameLabel = new System.Windows.Forms.Label();
            this.MName = new System.Windows.Forms.TextBox();
            this.MNameLabel = new System.Windows.Forms.Label();
            this.FName = new System.Windows.Forms.TextBox();
            this.FNameLabel = new System.Windows.Forms.Label();
            this.Branch = new System.Windows.Forms.TabPage();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.DeleteBranch = new System.Windows.Forms.Button();
            this.UpdateBranch = new System.Windows.Forms.Button();
            this.CreateBranch = new System.Windows.Forms.Button();
            this.BPhoneNumber = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.BProvince = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.BPostalCode = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.BCity = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.BID = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.BStreet_Address2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.BStreet_Address1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.BDescription = new System.Windows.Forms.TextBox();
            this.DescriptionLabel = new System.Windows.Forms.Label();
            this.DisplayButton = new System.Windows.Forms.TabPage();
            this.label62 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label53 = new System.Windows.Forms.Label();
            this.displaydtime = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.displayddate = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.displaydbranch = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.displayptime = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.displaypdate = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.displaypbranch = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.dropoffTimeAMPM = new System.Windows.Forms.ComboBox();
            this.dropoffMinute = new System.Windows.Forms.NumericUpDown();
            this.dropoffHour = new System.Windows.Forms.NumericUpDown();
            this.dropoffDate = new System.Windows.Forms.DateTimePicker();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.pickupTimeAMPM = new System.Windows.Forms.ComboBox();
            this.pickupMinute = new System.Windows.Forms.NumericUpDown();
            this.pickupHour = new System.Windows.Forms.NumericUpDown();
            this.pickupDate = new System.Windows.Forms.DateTimePicker();
            this.label18 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.dropoffbranchBox = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.pickupbranchBox = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.TransactionID = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.CBID = new System.Windows.Forms.ComboBox();
            this.branchBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this._291_group2DataSet = new _291_Group2._291_group2DataSet();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.CCarType = new System.Windows.Forms.ComboBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.AddCar = new System.Windows.Forms.Button();
            this.CInsurance = new System.Windows.Forms.TextBox();
            this.Color = new System.Windows.Forms.TextBox();
            this.Odometer = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.Seats = new System.Windows.Forms.TextBox();
            this.Year = new System.Windows.Forms.TextBox();
            this.Model = new System.Windows.Forms.TextBox();
            this.Make = new System.Windows.Forms.TextBox();
            this.VIN = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.CarType = new System.Windows.Forms.TabPage();
            this.CTCarTypeID = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.DailyRate = new System.Windows.Forms.TextBox();
            this.WeeklyRate = new System.Windows.Forms.TextBox();
            this.MonthlyRate = new System.Windows.Forms.TextBox();
            this.CTCarDescription = new System.Windows.Forms.ComboBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.Report = new System.Windows.Forms.Button();
            this.label52 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label48 = new System.Windows.Forms.Label();
            this.branchTableAdapter = new _291_Group2._291_group2DataSetTableAdapters.BranchTableAdapter();
            this.branchTableAdapter1 = new _291_Group2._291_group2DataSetTableAdapters.BranchTableAdapter();
            this.branchTableAdapter2 = new _291_Group2._291_group2DataSetTableAdapters.BranchTableAdapter();
            this.customerTableAdapter1 = new _291_Group2._291_group2DataSetTableAdapters.CustomerTableAdapter();
            this.GetBranch = new System.Windows.Forms.Button();
            this.PrevBranch = new System.Windows.Forms.Button();
            this.NextBranch = new System.Windows.Forms.Button();
            this.Customer.SuspendLayout();
            this.Customers.SuspendLayout();
            this.Branch.SuspendLayout();
            this.DisplayButton.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dropoffMinute)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dropoffHour)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pickupMinute)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pickupHour)).BeginInit();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.branchBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._291_group2DataSet)).BeginInit();
            this.CarType.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // Customer
            // 
            this.Customer.AccessibleName = "Rentals";
            this.Customer.Controls.Add(this.Customers);
            this.Customer.Controls.Add(this.Branch);
            this.Customer.Controls.Add(this.DisplayButton);
            this.Customer.Controls.Add(this.tabPage1);
            this.Customer.Controls.Add(this.CarType);
            this.Customer.Controls.Add(this.tabPage3);
            this.Customer.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Customer.Location = new System.Drawing.Point(43, 20);
            this.Customer.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Customer.Name = "Customer";
            this.Customer.SelectedIndex = 0;
            this.Customer.Size = new System.Drawing.Size(1059, 686);
            this.Customer.TabIndex = 0;
            // 
            // Customers
            // 
            this.Customers.BackColor = System.Drawing.Color.LightYellow;
            this.Customers.Controls.Add(this.GetCustomer);
            this.Customers.Controls.Add(this.PrevCustomer);
            this.Customers.Controls.Add(this.NextCustomer);
            this.Customers.Controls.Add(this.Province);
            this.Customers.Controls.Add(this.ProvinceLabel);
            this.Customers.Controls.Add(this.DeleteCustomer);
            this.Customers.Controls.Add(this.MembershipG);
            this.Customers.Controls.Add(this.MembershipS);
            this.Customers.Controls.Add(this.UpdateCustomer);
            this.Customers.Controls.Add(this.DOB);
            this.Customers.Controls.Add(this.CreateCustomer);
            this.Customers.Controls.Add(this.label2);
            this.Customers.Controls.Add(this.CID);
            this.Customers.Controls.Add(this.CustomerIDLabel);
            this.Customers.Controls.Add(this.DriverLicense);
            this.Customers.Controls.Add(this.DriversLabel);
            this.Customers.Controls.Add(this.Insurance);
            this.Customers.Controls.Add(this.InsuranceLabel);
            this.Customers.Controls.Add(this.PhoneNumber);
            this.Customers.Controls.Add(this.PhoneLabel);
            this.Customers.Controls.Add(this.label1);
            this.Customers.Controls.Add(this.PostalCode);
            this.Customers.Controls.Add(this.PostalCodeLabel);
            this.Customers.Controls.Add(this.City);
            this.Customers.Controls.Add(this.CityLabel);
            this.Customers.Controls.Add(this.StreetAddress2);
            this.Customers.Controls.Add(this.label5);
            this.Customers.Controls.Add(this.StreetAddress1);
            this.Customers.Controls.Add(this.StreetAddressLabel1);
            this.Customers.Controls.Add(this.LName);
            this.Customers.Controls.Add(this.LNameLabel);
            this.Customers.Controls.Add(this.MName);
            this.Customers.Controls.Add(this.MNameLabel);
            this.Customers.Controls.Add(this.FName);
            this.Customers.Controls.Add(this.FNameLabel);
            this.Customers.Location = new System.Drawing.Point(4, 25);
            this.Customers.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Customers.Name = "Customers";
            this.Customers.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Customers.Size = new System.Drawing.Size(1051, 657);
            this.Customers.TabIndex = 0;
            this.Customers.Text = "Customers";
            this.Customers.Click += new System.EventHandler(this.Customers_Click);
            // 
            // GetCustomer
            // 
            this.GetCustomer.Location = new System.Drawing.Point(227, 494);
            this.GetCustomer.Name = "GetCustomer";
            this.GetCustomer.Size = new System.Drawing.Size(157, 31);
            this.GetCustomer.TabIndex = 34;
            this.GetCustomer.Text = "Get Customer";
            this.GetCustomer.UseVisualStyleBackColor = true;
            this.GetCustomer.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // PrevCustomer
            // 
            this.PrevCustomer.Location = new System.Drawing.Point(433, 494);
            this.PrevCustomer.Name = "PrevCustomer";
            this.PrevCustomer.Size = new System.Drawing.Size(157, 31);
            this.PrevCustomer.TabIndex = 34;
            this.PrevCustomer.Text = "Previous Customer";
            this.PrevCustomer.UseVisualStyleBackColor = true;
            this.PrevCustomer.Click += new System.EventHandler(this.PrevCustomer_Click);
            // 
            // NextCustomer
            // 
            this.NextCustomer.Location = new System.Drawing.Point(632, 494);
            this.NextCustomer.Name = "NextCustomer";
            this.NextCustomer.Size = new System.Drawing.Size(157, 31);
            this.NextCustomer.TabIndex = 34;
            this.NextCustomer.Text = "Next Customer";
            this.NextCustomer.UseVisualStyleBackColor = true;
            this.NextCustomer.Click += new System.EventHandler(this.NextCustomer_Click);
            // 
            // Province
            // 
            this.Province.Location = new System.Drawing.Point(749, 99);
            this.Province.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Province.Name = "Province";
            this.Province.Size = new System.Drawing.Size(189, 22);
            this.Province.TabIndex = 33;
            this.Province.TextChanged += new System.EventHandler(this.textBox2_TextChanged_1);
            // 
            // ProvinceLabel
            // 
            this.ProvinceLabel.AutoSize = true;
            this.ProvinceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProvinceLabel.Location = new System.Drawing.Point(633, 96);
            this.ProvinceLabel.Name = "ProvinceLabel";
            this.ProvinceLabel.Size = new System.Drawing.Size(96, 25);
            this.ProvinceLabel.TabIndex = 32;
            this.ProvinceLabel.Text = "Province";
            this.ProvinceLabel.Click += new System.EventHandler(this.label8_Click);
            // 
            // DeleteCustomer
            // 
            this.DeleteCustomer.BackColor = System.Drawing.Color.SkyBlue;
            this.DeleteCustomer.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.DeleteCustomer.Location = new System.Drawing.Point(707, 548);
            this.DeleteCustomer.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DeleteCustomer.Name = "DeleteCustomer";
            this.DeleteCustomer.Size = new System.Drawing.Size(261, 64);
            this.DeleteCustomer.TabIndex = 31;
            this.DeleteCustomer.Text = "Delete Customer";
            this.DeleteCustomer.UseVisualStyleBackColor = false;
            this.DeleteCustomer.Click += new System.EventHandler(this.DeleteCustomer_Click);
            // 
            // MembershipG
            // 
            this.MembershipG.AutoSize = true;
            this.MembershipG.Location = new System.Drawing.Point(889, 435);
            this.MembershipG.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MembershipG.Name = "MembershipG";
            this.MembershipG.Size = new System.Drawing.Size(61, 20);
            this.MembershipG.TabIndex = 30;
            this.MembershipG.TabStop = true;
            this.MembershipG.Text = "Gold";
            this.MembershipG.UseVisualStyleBackColor = true;
            // 
            // MembershipS
            // 
            this.MembershipS.AutoSize = true;
            this.MembershipS.Location = new System.Drawing.Point(763, 435);
            this.MembershipS.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MembershipS.Name = "MembershipS";
            this.MembershipS.Size = new System.Drawing.Size(91, 20);
            this.MembershipS.TabIndex = 29;
            this.MembershipS.TabStop = true;
            this.MembershipS.Text = "Standard";
            this.MembershipS.UseVisualStyleBackColor = true;
            // 
            // UpdateCustomer
            // 
            this.UpdateCustomer.BackColor = System.Drawing.Color.SkyBlue;
            this.UpdateCustomer.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.UpdateCustomer.Location = new System.Drawing.Point(391, 548);
            this.UpdateCustomer.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.UpdateCustomer.Name = "UpdateCustomer";
            this.UpdateCustomer.Size = new System.Drawing.Size(261, 64);
            this.UpdateCustomer.TabIndex = 28;
            this.UpdateCustomer.Text = "Update Information";
            this.UpdateCustomer.UseVisualStyleBackColor = false;
            this.UpdateCustomer.Click += new System.EventHandler(this.UpdateCustomer_Click);
            // 
            // DOB
            // 
            this.DOB.Location = new System.Drawing.Point(248, 321);
            this.DOB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DOB.Name = "DOB";
            this.DOB.Size = new System.Drawing.Size(188, 22);
            this.DOB.TabIndex = 27;
            // 
            // CreateCustomer
            // 
            this.CreateCustomer.BackColor = System.Drawing.Color.SkyBlue;
            this.CreateCustomer.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.CreateCustomer.Location = new System.Drawing.Point(81, 548);
            this.CreateCustomer.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CreateCustomer.Name = "CreateCustomer";
            this.CreateCustomer.Size = new System.Drawing.Size(261, 64);
            this.CreateCustomer.TabIndex = 26;
            this.CreateCustomer.Text = "Register New Customer";
            this.CreateCustomer.UseVisualStyleBackColor = false;
            this.CreateCustomer.Click += new System.EventHandler(this.CreateCustomer_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(533, 433);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(198, 25);
            this.label2.TabIndex = 24;
            this.label2.Text = "Membership Status";
            this.label2.Click += new System.EventHandler(this.label2_Click_2);
            // 
            // CID
            // 
            this.CID.Location = new System.Drawing.Point(248, 41);
            this.CID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CID.Name = "CID";
            this.CID.Size = new System.Drawing.Size(189, 22);
            this.CID.TabIndex = 23;
            this.CID.TextChanged += new System.EventHandler(this.CID_TextChanged);
            // 
            // CustomerIDLabel
            // 
            this.CustomerIDLabel.AutoSize = true;
            this.CustomerIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerIDLabel.Location = new System.Drawing.Point(100, 41);
            this.CustomerIDLabel.Name = "CustomerIDLabel";
            this.CustomerIDLabel.Size = new System.Drawing.Size(132, 25);
            this.CustomerIDLabel.TabIndex = 22;
            this.CustomerIDLabel.Text = "Customer ID";
            this.CustomerIDLabel.Click += new System.EventHandler(this.CustomerIDLabel_Click);
            // 
            // DriverLicense
            // 
            this.DriverLicense.Location = new System.Drawing.Point(749, 382);
            this.DriverLicense.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DriverLicense.Name = "DriverLicense";
            this.DriverLicense.Size = new System.Drawing.Size(189, 22);
            this.DriverLicense.TabIndex = 21;
            this.DriverLicense.TextChanged += new System.EventHandler(this.DriverLicense_TextChanged);
            // 
            // DriversLabel
            // 
            this.DriversLabel.AutoSize = true;
            this.DriversLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DriversLabel.Location = new System.Drawing.Point(572, 379);
            this.DriversLabel.Name = "DriversLabel";
            this.DriversLabel.Size = new System.Drawing.Size(161, 25);
            this.DriversLabel.TabIndex = 20;
            this.DriversLabel.Text = "Drivers License";
            // 
            // Insurance
            // 
            this.Insurance.Location = new System.Drawing.Point(749, 308);
            this.Insurance.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Insurance.Name = "Insurance";
            this.Insurance.Size = new System.Drawing.Size(189, 22);
            this.Insurance.TabIndex = 19;
            this.Insurance.TextChanged += new System.EventHandler(this.textBox3_TextChanged_1);
            // 
            // InsuranceLabel
            // 
            this.InsuranceLabel.AutoSize = true;
            this.InsuranceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InsuranceLabel.Location = new System.Drawing.Point(627, 308);
            this.InsuranceLabel.Name = "InsuranceLabel";
            this.InsuranceLabel.Size = new System.Drawing.Size(107, 25);
            this.InsuranceLabel.TabIndex = 18;
            this.InsuranceLabel.Text = "Insurance";
            // 
            // PhoneNumber
            // 
            this.PhoneNumber.Location = new System.Drawing.Point(749, 248);
            this.PhoneNumber.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PhoneNumber.Name = "PhoneNumber";
            this.PhoneNumber.Size = new System.Drawing.Size(189, 22);
            this.PhoneNumber.TabIndex = 17;
            this.PhoneNumber.TextChanged += new System.EventHandler(this.PhoneNumber_TextChanged);
            // 
            // PhoneLabel
            // 
            this.PhoneLabel.AutoSize = true;
            this.PhoneLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhoneLabel.Location = new System.Drawing.Point(568, 248);
            this.PhoneLabel.Name = "PhoneLabel";
            this.PhoneLabel.Size = new System.Drawing.Size(155, 25);
            this.PhoneLabel.TabIndex = 16;
            this.PhoneLabel.Text = "Phone Number";
            this.PhoneLabel.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(93, 321);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 25);
            this.label1.TabIndex = 14;
            this.label1.Text = "Date of Birth";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // PostalCode
            // 
            this.PostalCode.Location = new System.Drawing.Point(749, 173);
            this.PostalCode.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PostalCode.Name = "PostalCode";
            this.PostalCode.Size = new System.Drawing.Size(189, 22);
            this.PostalCode.TabIndex = 13;
            this.PostalCode.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // PostalCodeLabel
            // 
            this.PostalCodeLabel.AutoSize = true;
            this.PostalCodeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PostalCodeLabel.Location = new System.Drawing.Point(597, 173);
            this.PostalCodeLabel.Name = "PostalCodeLabel";
            this.PostalCodeLabel.Size = new System.Drawing.Size(130, 25);
            this.PostalCodeLabel.TabIndex = 12;
            this.PostalCodeLabel.Text = "Postal Code";
            this.PostalCodeLabel.Click += new System.EventHandler(this.label2_Click);
            // 
            // City
            // 
            this.City.Location = new System.Drawing.Point(749, 37);
            this.City.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.City.Name = "City";
            this.City.Size = new System.Drawing.Size(189, 22);
            this.City.TabIndex = 11;
            this.City.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // CityLabel
            // 
            this.CityLabel.AutoSize = true;
            this.CityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CityLabel.Location = new System.Drawing.Point(681, 37);
            this.CityLabel.Name = "CityLabel";
            this.CityLabel.Size = new System.Drawing.Size(50, 25);
            this.CityLabel.TabIndex = 10;
            this.CityLabel.Text = "City";
            this.CityLabel.Click += new System.EventHandler(this.label3_Click);
            // 
            // StreetAddress2
            // 
            this.StreetAddress2.Location = new System.Drawing.Point(248, 447);
            this.StreetAddress2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.StreetAddress2.Name = "StreetAddress2";
            this.StreetAddress2.Size = new System.Drawing.Size(189, 22);
            this.StreetAddress2.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(51, 444);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(174, 25);
            this.label5.TabIndex = 8;
            this.label5.Text = "Street Address 2";
            // 
            // StreetAddress1
            // 
            this.StreetAddress1.Location = new System.Drawing.Point(248, 390);
            this.StreetAddress1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.StreetAddress1.Name = "StreetAddress1";
            this.StreetAddress1.Size = new System.Drawing.Size(189, 22);
            this.StreetAddress1.TabIndex = 7;
            // 
            // StreetAddressLabel1
            // 
            this.StreetAddressLabel1.AutoSize = true;
            this.StreetAddressLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StreetAddressLabel1.Location = new System.Drawing.Point(52, 386);
            this.StreetAddressLabel1.Name = "StreetAddressLabel1";
            this.StreetAddressLabel1.Size = new System.Drawing.Size(174, 25);
            this.StreetAddressLabel1.TabIndex = 6;
            this.StreetAddressLabel1.Text = "Street Address 1";
            this.StreetAddressLabel1.Click += new System.EventHandler(this.Address1Label_Click);
            // 
            // LName
            // 
            this.LName.Location = new System.Drawing.Point(248, 252);
            this.LName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LName.Name = "LName";
            this.LName.Size = new System.Drawing.Size(189, 22);
            this.LName.TabIndex = 5;
            // 
            // LNameLabel
            // 
            this.LNameLabel.AutoSize = true;
            this.LNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LNameLabel.Location = new System.Drawing.Point(117, 250);
            this.LNameLabel.Name = "LNameLabel";
            this.LNameLabel.Size = new System.Drawing.Size(115, 25);
            this.LNameLabel.TabIndex = 4;
            this.LNameLabel.Text = "Last Name";
            this.LNameLabel.Click += new System.EventHandler(this.LNameLabel_Click);
            // 
            // MName
            // 
            this.MName.Location = new System.Drawing.Point(248, 177);
            this.MName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MName.Name = "MName";
            this.MName.Size = new System.Drawing.Size(189, 22);
            this.MName.TabIndex = 3;
            // 
            // MNameLabel
            // 
            this.MNameLabel.AutoSize = true;
            this.MNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MNameLabel.Location = new System.Drawing.Point(93, 177);
            this.MNameLabel.Name = "MNameLabel";
            this.MNameLabel.Size = new System.Drawing.Size(138, 25);
            this.MNameLabel.TabIndex = 2;
            this.MNameLabel.Text = "Middle Name";
            // 
            // FName
            // 
            this.FName.Location = new System.Drawing.Point(248, 110);
            this.FName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.FName.Name = "FName";
            this.FName.Size = new System.Drawing.Size(189, 22);
            this.FName.TabIndex = 1;
            this.FName.TextChanged += new System.EventHandler(this.FName_TextChanged);
            // 
            // FNameLabel
            // 
            this.FNameLabel.AutoSize = true;
            this.FNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FNameLabel.Location = new System.Drawing.Point(116, 110);
            this.FNameLabel.Name = "FNameLabel";
            this.FNameLabel.Size = new System.Drawing.Size(116, 25);
            this.FNameLabel.TabIndex = 0;
            this.FNameLabel.Text = "First Name";
            this.FNameLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // Branch
            // 
            this.Branch.BackColor = System.Drawing.Color.Honeydew;
            this.Branch.Controls.Add(this.NextBranch);
            this.Branch.Controls.Add(this.PrevBranch);
            this.Branch.Controls.Add(this.GetBranch);
            this.Branch.Controls.Add(this.checkBox2);
            this.Branch.Controls.Add(this.DeleteBranch);
            this.Branch.Controls.Add(this.UpdateBranch);
            this.Branch.Controls.Add(this.CreateBranch);
            this.Branch.Controls.Add(this.BPhoneNumber);
            this.Branch.Controls.Add(this.label10);
            this.Branch.Controls.Add(this.BProvince);
            this.Branch.Controls.Add(this.label8);
            this.Branch.Controls.Add(this.BPostalCode);
            this.Branch.Controls.Add(this.label9);
            this.Branch.Controls.Add(this.BCity);
            this.Branch.Controls.Add(this.label7);
            this.Branch.Controls.Add(this.BID);
            this.Branch.Controls.Add(this.label3);
            this.Branch.Controls.Add(this.BStreet_Address2);
            this.Branch.Controls.Add(this.label4);
            this.Branch.Controls.Add(this.BStreet_Address1);
            this.Branch.Controls.Add(this.label6);
            this.Branch.Controls.Add(this.BDescription);
            this.Branch.Controls.Add(this.DescriptionLabel);
            this.Branch.Location = new System.Drawing.Point(4, 25);
            this.Branch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Branch.Name = "Branch";
            this.Branch.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Branch.Size = new System.Drawing.Size(1051, 657);
            this.Branch.TabIndex = 1;
            this.Branch.Text = "Branch";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(493, 26);
            this.checkBox2.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(72, 20);
            this.checkBox2.TabIndex = 76;
            this.checkBox2.Text = "Admin";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // DeleteBranch
            // 
            this.DeleteBranch.BackColor = System.Drawing.Color.SkyBlue;
            this.DeleteBranch.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.DeleteBranch.Location = new System.Drawing.Point(719, 507);
            this.DeleteBranch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DeleteBranch.Name = "DeleteBranch";
            this.DeleteBranch.Size = new System.Drawing.Size(261, 64);
            this.DeleteBranch.TabIndex = 46;
            this.DeleteBranch.Text = "Delete Branch";
            this.DeleteBranch.UseVisualStyleBackColor = false;
            this.DeleteBranch.Click += new System.EventHandler(this.DeleteBranch_Click);
            // 
            // UpdateBranch
            // 
            this.UpdateBranch.BackColor = System.Drawing.Color.SkyBlue;
            this.UpdateBranch.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.UpdateBranch.Location = new System.Drawing.Point(403, 507);
            this.UpdateBranch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.UpdateBranch.Name = "UpdateBranch";
            this.UpdateBranch.Size = new System.Drawing.Size(261, 64);
            this.UpdateBranch.TabIndex = 45;
            this.UpdateBranch.Text = "Update Branch";
            this.UpdateBranch.UseVisualStyleBackColor = false;
            this.UpdateBranch.Click += new System.EventHandler(this.UpdateBranch_Click);
            // 
            // CreateBranch
            // 
            this.CreateBranch.BackColor = System.Drawing.Color.SkyBlue;
            this.CreateBranch.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.CreateBranch.Location = new System.Drawing.Point(81, 507);
            this.CreateBranch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CreateBranch.Name = "CreateBranch";
            this.CreateBranch.Size = new System.Drawing.Size(261, 64);
            this.CreateBranch.TabIndex = 44;
            this.CreateBranch.Text = "Create Branch";
            this.CreateBranch.UseVisualStyleBackColor = false;
            this.CreateBranch.Click += new System.EventHandler(this.CreateBranch_Click);
            // 
            // BPhoneNumber
            // 
            this.BPhoneNumber.Location = new System.Drawing.Point(697, 145);
            this.BPhoneNumber.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BPhoneNumber.Name = "BPhoneNumber";
            this.BPhoneNumber.Size = new System.Drawing.Size(189, 22);
            this.BPhoneNumber.TabIndex = 43;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(489, 340);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(155, 25);
            this.label10.TabIndex = 42;
            this.label10.Text = "Phone Number";
            // 
            // BProvince
            // 
            this.BProvince.Location = new System.Drawing.Point(697, 213);
            this.BProvince.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BProvince.Name = "BProvince";
            this.BProvince.Size = new System.Drawing.Size(189, 22);
            this.BProvince.TabIndex = 41;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(553, 209);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 25);
            this.label8.TabIndex = 40;
            this.label8.Text = "Province";
            // 
            // BPostalCode
            // 
            this.BPostalCode.Location = new System.Drawing.Point(697, 271);
            this.BPostalCode.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BPostalCode.Name = "BPostalCode";
            this.BPostalCode.Size = new System.Drawing.Size(189, 22);
            this.BPostalCode.TabIndex = 39;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(517, 271);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(130, 25);
            this.label9.TabIndex = 38;
            this.label9.Text = "Postal Code";
            // 
            // BCity
            // 
            this.BCity.Location = new System.Drawing.Point(697, 343);
            this.BCity.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BCity.Name = "BCity";
            this.BCity.Size = new System.Drawing.Size(189, 22);
            this.BCity.TabIndex = 37;
            this.BCity.TextChanged += new System.EventHandler(this.BCity_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(594, 145);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 25);
            this.label7.TabIndex = 36;
            this.label7.Text = "City";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BID
            // 
            this.BID.Location = new System.Drawing.Point(247, 145);
            this.BID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BID.Name = "BID";
            this.BID.Size = new System.Drawing.Size(189, 22);
            this.BID.TabIndex = 35;
            this.BID.TextChanged += new System.EventHandler(this.BID_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(124, 141);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 25);
            this.label3.TabIndex = 34;
            this.label3.Text = "Branch ID";
            // 
            // BStreet_Address2
            // 
            this.BStreet_Address2.Location = new System.Drawing.Point(247, 344);
            this.BStreet_Address2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BStreet_Address2.Name = "BStreet_Address2";
            this.BStreet_Address2.Size = new System.Drawing.Size(189, 22);
            this.BStreet_Address2.TabIndex = 33;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(59, 340);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(174, 25);
            this.label4.TabIndex = 32;
            this.label4.Text = "Street Address 2";
            // 
            // BStreet_Address1
            // 
            this.BStreet_Address1.Location = new System.Drawing.Point(247, 275);
            this.BStreet_Address1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BStreet_Address1.Name = "BStreet_Address1";
            this.BStreet_Address1.Size = new System.Drawing.Size(189, 22);
            this.BStreet_Address1.TabIndex = 31;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(57, 271);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(174, 25);
            this.label6.TabIndex = 30;
            this.label6.Text = "Street Address 1";
            // 
            // BDescription
            // 
            this.BDescription.Location = new System.Drawing.Point(247, 213);
            this.BDescription.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BDescription.Name = "BDescription";
            this.BDescription.Size = new System.Drawing.Size(189, 22);
            this.BDescription.TabIndex = 25;
            // 
            // DescriptionLabel
            // 
            this.DescriptionLabel.AutoSize = true;
            this.DescriptionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DescriptionLabel.Location = new System.Drawing.Point(111, 209);
            this.DescriptionLabel.Name = "DescriptionLabel";
            this.DescriptionLabel.Size = new System.Drawing.Size(120, 25);
            this.DescriptionLabel.TabIndex = 24;
            this.DescriptionLabel.Text = "Description";
            // 
            // DisplayButton
            // 
            this.DisplayButton.BackColor = System.Drawing.Color.PowderBlue;
            this.DisplayButton.Controls.Add(this.label62);
            this.DisplayButton.Controls.Add(this.label41);
            this.DisplayButton.Controls.Add(this.label40);
            this.DisplayButton.Controls.Add(this.label61);
            this.DisplayButton.Controls.Add(this.label60);
            this.DisplayButton.Controls.Add(this.label58);
            this.DisplayButton.Controls.Add(this.label59);
            this.DisplayButton.Controls.Add(this.label57);
            this.DisplayButton.Controls.Add(this.label56);
            this.DisplayButton.Controls.Add(this.label54);
            this.DisplayButton.Controls.Add(this.label55);
            this.DisplayButton.Controls.Add(this.comboBox5);
            this.DisplayButton.Controls.Add(this.label53);
            this.DisplayButton.Controls.Add(this.displaydtime);
            this.DisplayButton.Controls.Add(this.label24);
            this.DisplayButton.Controls.Add(this.displayddate);
            this.DisplayButton.Controls.Add(this.label27);
            this.DisplayButton.Controls.Add(this.displaydbranch);
            this.DisplayButton.Controls.Add(this.label29);
            this.DisplayButton.Controls.Add(this.displayptime);
            this.DisplayButton.Controls.Add(this.label25);
            this.DisplayButton.Controls.Add(this.displaypdate);
            this.DisplayButton.Controls.Add(this.label23);
            this.DisplayButton.Controls.Add(this.displaypbranch);
            this.DisplayButton.Controls.Add(this.label21);
            this.DisplayButton.Controls.Add(this.button2);
            this.DisplayButton.Controls.Add(this.label17);
            this.DisplayButton.Controls.Add(this.label16);
            this.DisplayButton.Controls.Add(this.button1);
            this.DisplayButton.Controls.Add(this.dropoffTimeAMPM);
            this.DisplayButton.Controls.Add(this.dropoffMinute);
            this.DisplayButton.Controls.Add(this.dropoffHour);
            this.DisplayButton.Controls.Add(this.dropoffDate);
            this.DisplayButton.Controls.Add(this.label19);
            this.DisplayButton.Controls.Add(this.label20);
            this.DisplayButton.Controls.Add(this.pickupTimeAMPM);
            this.DisplayButton.Controls.Add(this.pickupMinute);
            this.DisplayButton.Controls.Add(this.pickupHour);
            this.DisplayButton.Controls.Add(this.pickupDate);
            this.DisplayButton.Controls.Add(this.label18);
            this.DisplayButton.Controls.Add(this.label15);
            this.DisplayButton.Controls.Add(this.label14);
            this.DisplayButton.Controls.Add(this.dropoffbranchBox);
            this.DisplayButton.Controls.Add(this.label13);
            this.DisplayButton.Controls.Add(this.pickupbranchBox);
            this.DisplayButton.Controls.Add(this.label12);
            this.DisplayButton.Controls.Add(this.TransactionID);
            this.DisplayButton.Controls.Add(this.label11);
            this.DisplayButton.Location = new System.Drawing.Point(4, 25);
            this.DisplayButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DisplayButton.Name = "DisplayButton";
            this.DisplayButton.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DisplayButton.Size = new System.Drawing.Size(1051, 657);
            this.DisplayButton.TabIndex = 2;
            this.DisplayButton.Text = "Rentals";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(961, 401);
            this.label62.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(43, 16);
            this.label62.TabIndex = 49;
            this.label62.Text = "$0.00";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.ForeColor = System.Drawing.Color.Red;
            this.label41.Location = new System.Drawing.Point(767, 401);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(163, 16);
            this.label41.TabIndex = 48;
            this.label41.Text = "*Late fee if applicable:";
            this.label41.Visible = false;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(604, 605);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(0, 16);
            this.label40.TabIndex = 47;
            this.label40.Visible = false;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(961, 380);
            this.label61.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(43, 16);
            this.label61.TabIndex = 46;
            this.label61.Text = "$7.53";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.ForeColor = System.Drawing.Color.Red;
            this.label60.Location = new System.Drawing.Point(890, 380);
            this.label60.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(42, 16);
            this.label60.TabIndex = 45;
            this.label60.Text = "GST:";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(961, 351);
            this.label58.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(59, 16);
            this.label58.TabIndex = 44;
            this.label58.Text = "$150.50";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.ForeColor = System.Drawing.Color.Red;
            this.label59.Location = new System.Drawing.Point(654, 351);
            this.label59.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(275, 16);
            this.label59.TabIndex = 43;
            this.label59.Text = "Calculated rate based on days and car";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.ForeColor = System.Drawing.Color.Red;
            this.label57.Location = new System.Drawing.Point(119, 401);
            this.label57.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(154, 16);
            this.label57.TabIndex = 42;
            this.label57.Text = "Rates for chosen car:";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(318, 401);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(164, 16);
            this.label56.TabIndex = 41;
            this.label56.Text = "Daily, Weekly, Monthly";
            this.label56.Click += new System.EventHandler(this.label56_Click);
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(961, 428);
            this.label54.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(59, 16);
            this.label54.TabIndex = 40;
            this.label54.Text = "$158.03";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.ForeColor = System.Drawing.Color.Red;
            this.label55.Location = new System.Drawing.Point(833, 428);
            this.label55.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(99, 16);
            this.label55.TabIndex = 39;
            this.label55.Text = "Total charge:";
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "Economy",
            "Compact",
            "Mid-Size",
            "Full-Size",
            "Luxury",
            "Compact SUV",
            "Full-size SUV",
            "Minivan",
            "Passenger Van",
            "Pick-up Truck"});
            this.comboBox5.Location = new System.Drawing.Point(321, 343);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(282, 24);
            this.comboBox5.TabIndex = 38;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(48, 351);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(225, 16);
            this.label53.TabIndex = 37;
            this.label53.Text = "Choose from available vehicles";
            // 
            // displaydtime
            // 
            this.displaydtime.AutoSize = true;
            this.displaydtime.Location = new System.Drawing.Point(625, 552);
            this.displaydtime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.displaydtime.Name = "displaydtime";
            this.displaydtime.Size = new System.Drawing.Size(89, 16);
            this.displaydtime.TabIndex = 36;
            this.displaydtime.Text = "dropoff time";
            this.displaydtime.Visible = false;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ForeColor = System.Drawing.Color.Red;
            this.label24.Location = new System.Drawing.Point(493, 552);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(95, 16);
            this.label24.TabIndex = 35;
            this.label24.Text = "Dropoff time:";
            // 
            // displayddate
            // 
            this.displayddate.AutoSize = true;
            this.displayddate.Location = new System.Drawing.Point(625, 520);
            this.displayddate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.displayddate.Name = "displayddate";
            this.displayddate.Size = new System.Drawing.Size(91, 16);
            this.displayddate.TabIndex = 34;
            this.displayddate.Text = "dropoff date";
            this.displayddate.Visible = false;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.ForeColor = System.Drawing.Color.Red;
            this.label27.Location = new System.Drawing.Point(493, 520);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(97, 16);
            this.label27.TabIndex = 33;
            this.label27.Text = "Dropoff date:";
            // 
            // displaydbranch
            // 
            this.displaydbranch.AutoSize = true;
            this.displaydbranch.Location = new System.Drawing.Point(625, 488);
            this.displaydbranch.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.displaydbranch.Name = "displaydbranch";
            this.displaydbranch.Size = new System.Drawing.Size(107, 16);
            this.displaydbranch.TabIndex = 32;
            this.displaydbranch.Text = "dropoff branch";
            this.displaydbranch.Visible = false;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.ForeColor = System.Drawing.Color.Red;
            this.label29.Location = new System.Drawing.Point(493, 488);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(113, 16);
            this.label29.TabIndex = 31;
            this.label29.Text = "Dropoff branch:";
            // 
            // displayptime
            // 
            this.displayptime.AutoSize = true;
            this.displayptime.Location = new System.Drawing.Point(160, 552);
            this.displayptime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.displayptime.Name = "displayptime";
            this.displayptime.Size = new System.Drawing.Size(86, 16);
            this.displayptime.TabIndex = 30;
            this.displayptime.Text = "pickup time";
            this.displayptime.Visible = false;
            this.displayptime.Click += new System.EventHandler(this.label24_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.ForeColor = System.Drawing.Color.Red;
            this.label25.Location = new System.Drawing.Point(28, 552);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(91, 16);
            this.label25.TabIndex = 29;
            this.label25.Text = "Pickup time:";
            // 
            // displaypdate
            // 
            this.displaypdate.AutoSize = true;
            this.displaypdate.Location = new System.Drawing.Point(160, 520);
            this.displaypdate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.displaypdate.Name = "displaypdate";
            this.displaypdate.Size = new System.Drawing.Size(88, 16);
            this.displaypdate.TabIndex = 28;
            this.displaypdate.Text = "pickup date";
            this.displaypdate.Visible = false;
            this.displaypdate.Click += new System.EventHandler(this.label22_Click_1);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.Color.Red;
            this.label23.Location = new System.Drawing.Point(28, 520);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(93, 16);
            this.label23.TabIndex = 27;
            this.label23.Text = "Pickup date:";
            // 
            // displaypbranch
            // 
            this.displaypbranch.AutoSize = true;
            this.displaypbranch.Location = new System.Drawing.Point(160, 488);
            this.displaypbranch.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.displaypbranch.Name = "displaypbranch";
            this.displaypbranch.Size = new System.Drawing.Size(104, 16);
            this.displaypbranch.TabIndex = 26;
            this.displaypbranch.Text = "pickup branch";
            this.displaypbranch.Visible = false;
            this.displaypbranch.Click += new System.EventHandler(this.label22_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.Color.Red;
            this.label21.Location = new System.Drawing.Point(28, 488);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(109, 16);
            this.label21.TabIndex = 25;
            this.label21.Text = "Pickup branch:";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(833, 495);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(184, 73);
            this.button2.TabIndex = 24;
            this.button2.Text = "Rent";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(493, 103);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(366, 31);
            this.label17.TabIndex = 23;
            this.label17.Text = "DROPOFF INFORMATION";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(24, 449);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(249, 20);
            this.label16.TabIndex = 22;
            this.label16.Text = "Display selected information";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(304, 445);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 28);
            this.button1.TabIndex = 21;
            this.button1.Text = "Display";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dropoffTimeAMPM
            // 
            this.dropoffTimeAMPM.FormattingEnabled = true;
            this.dropoffTimeAMPM.Items.AddRange(new object[] {
            "AM",
            "PM"});
            this.dropoffTimeAMPM.Location = new System.Drawing.Point(801, 287);
            this.dropoffTimeAMPM.Margin = new System.Windows.Forms.Padding(4);
            this.dropoffTimeAMPM.Name = "dropoffTimeAMPM";
            this.dropoffTimeAMPM.Size = new System.Drawing.Size(91, 24);
            this.dropoffTimeAMPM.TabIndex = 20;
            // 
            // dropoffMinute
            // 
            this.dropoffMinute.Location = new System.Drawing.Point(725, 288);
            this.dropoffMinute.Margin = new System.Windows.Forms.Padding(4);
            this.dropoffMinute.Name = "dropoffMinute";
            this.dropoffMinute.Size = new System.Drawing.Size(68, 22);
            this.dropoffMinute.TabIndex = 19;
            // 
            // dropoffHour
            // 
            this.dropoffHour.Location = new System.Drawing.Point(648, 288);
            this.dropoffHour.Margin = new System.Windows.Forms.Padding(4);
            this.dropoffHour.Name = "dropoffHour";
            this.dropoffHour.Size = new System.Drawing.Size(69, 22);
            this.dropoffHour.TabIndex = 18;
            // 
            // dropoffDate
            // 
            this.dropoffDate.Location = new System.Drawing.Point(648, 235);
            this.dropoffDate.Margin = new System.Windows.Forms.Padding(4);
            this.dropoffDate.Name = "dropoffDate";
            this.dropoffDate.Size = new System.Drawing.Size(244, 22);
            this.dropoffDate.TabIndex = 17;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(496, 288);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(119, 20);
            this.label19.TabIndex = 16;
            this.label19.Text = "Dropoff Time";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(496, 235);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(118, 20);
            this.label20.TabIndex = 15;
            this.label20.Text = "Dropoff Date";
            // 
            // pickupTimeAMPM
            // 
            this.pickupTimeAMPM.FormattingEnabled = true;
            this.pickupTimeAMPM.Items.AddRange(new object[] {
            "AM",
            "PM"});
            this.pickupTimeAMPM.Location = new System.Drawing.Point(332, 283);
            this.pickupTimeAMPM.Margin = new System.Windows.Forms.Padding(4);
            this.pickupTimeAMPM.Name = "pickupTimeAMPM";
            this.pickupTimeAMPM.Size = new System.Drawing.Size(91, 24);
            this.pickupTimeAMPM.TabIndex = 14;
            this.pickupTimeAMPM.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // pickupMinute
            // 
            this.pickupMinute.Location = new System.Drawing.Point(256, 284);
            this.pickupMinute.Margin = new System.Windows.Forms.Padding(4);
            this.pickupMinute.Name = "pickupMinute";
            this.pickupMinute.Size = new System.Drawing.Size(68, 22);
            this.pickupMinute.TabIndex = 13;
            // 
            // pickupHour
            // 
            this.pickupHour.Location = new System.Drawing.Point(179, 284);
            this.pickupHour.Margin = new System.Windows.Forms.Padding(4);
            this.pickupHour.Name = "pickupHour";
            this.pickupHour.Size = new System.Drawing.Size(69, 22);
            this.pickupHour.TabIndex = 12;
            this.pickupHour.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // pickupDate
            // 
            this.pickupDate.Location = new System.Drawing.Point(179, 231);
            this.pickupDate.Margin = new System.Windows.Forms.Padding(4);
            this.pickupDate.Name = "pickupDate";
            this.pickupDate.Size = new System.Drawing.Size(244, 22);
            this.pickupDate.TabIndex = 11;
            this.pickupDate.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(41, 103);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(333, 31);
            this.label18.TabIndex = 10;
            this.label18.Text = "PICKUP INFORMATION";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(27, 284);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(112, 20);
            this.label15.TabIndex = 7;
            this.label15.Text = "Pickup Time";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(27, 231);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(111, 20);
            this.label14.TabIndex = 6;
            this.label14.Text = "Pickup Date";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // dropoffbranchBox
            // 
            this.dropoffbranchBox.FormattingEnabled = true;
            this.dropoffbranchBox.Items.AddRange(new object[] {
            "North Side",
            "West Side",
            "East Side",
            "South Side"});
            this.dropoffbranchBox.Location = new System.Drawing.Point(648, 170);
            this.dropoffbranchBox.Margin = new System.Windows.Forms.Padding(4);
            this.dropoffbranchBox.Name = "dropoffbranchBox";
            this.dropoffbranchBox.Size = new System.Drawing.Size(244, 24);
            this.dropoffbranchBox.TabIndex = 5;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(496, 176);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(135, 20);
            this.label13.TabIndex = 4;
            this.label13.Text = "Dropoff branch";
            // 
            // pickupbranchBox
            // 
            this.pickupbranchBox.FormattingEnabled = true;
            this.pickupbranchBox.Items.AddRange(new object[] {
            "North Side",
            "West Side",
            "East Side",
            "South Side"});
            this.pickupbranchBox.Location = new System.Drawing.Point(179, 170);
            this.pickupbranchBox.Margin = new System.Windows.Forms.Padding(4);
            this.pickupbranchBox.Name = "pickupbranchBox";
            this.pickupbranchBox.Size = new System.Drawing.Size(244, 24);
            this.pickupbranchBox.TabIndex = 3;
            this.pickupbranchBox.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(27, 176);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(128, 20);
            this.label12.TabIndex = 2;
            this.label12.Text = "Pickup branch";
            // 
            // TransactionID
            // 
            this.TransactionID.Location = new System.Drawing.Point(179, 22);
            this.TransactionID.Margin = new System.Windows.Forms.Padding(4);
            this.TransactionID.Name = "TransactionID";
            this.TransactionID.Size = new System.Drawing.Size(205, 22);
            this.TransactionID.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(27, 23);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(133, 20);
            this.label11.TabIndex = 0;
            this.label11.Text = "Transaction ID";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.LightCyan;
            this.tabPage1.Controls.Add(this.CBID);
            this.tabPage1.Controls.Add(this.checkBox3);
            this.tabPage1.Controls.Add(this.CCarType);
            this.tabPage1.Controls.Add(this.button5);
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Controls.Add(this.AddCar);
            this.tabPage1.Controls.Add(this.CInsurance);
            this.tabPage1.Controls.Add(this.Color);
            this.tabPage1.Controls.Add(this.Odometer);
            this.tabPage1.Controls.Add(this.label36);
            this.tabPage1.Controls.Add(this.label35);
            this.tabPage1.Controls.Add(this.label34);
            this.tabPage1.Controls.Add(this.label33);
            this.tabPage1.Controls.Add(this.label32);
            this.tabPage1.Controls.Add(this.Seats);
            this.tabPage1.Controls.Add(this.Year);
            this.tabPage1.Controls.Add(this.Model);
            this.tabPage1.Controls.Add(this.Make);
            this.tabPage1.Controls.Add(this.VIN);
            this.tabPage1.Controls.Add(this.label31);
            this.tabPage1.Controls.Add(this.label30);
            this.tabPage1.Controls.Add(this.label28);
            this.tabPage1.Controls.Add(this.label26);
            this.tabPage1.Controls.Add(this.label22);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(1051, 657);
            this.tabPage1.TabIndex = 3;
            this.tabPage1.Text = "Car";
            // 
            // CBID
            // 
            this.CBID.DataSource = this.branchBindingSource;
            this.CBID.DisplayMember = "BID";
            this.CBID.FormattingEnabled = true;
            this.CBID.Location = new System.Drawing.Point(772, 208);
            this.CBID.Name = "CBID";
            this.CBID.Size = new System.Drawing.Size(181, 24);
            this.CBID.TabIndex = 77;
            this.CBID.SelectedIndexChanged += new System.EventHandler(this.CBID_SelectedIndexChanged);
            // 
            // branchBindingSource
            // 
            this.branchBindingSource.DataMember = "Branch";
            this.branchBindingSource.DataSource = this._291_group2DataSet;
            this.branchBindingSource.CurrentChanged += new System.EventHandler(this.branchBindingSource_CurrentChanged);
            // 
            // _291_group2DataSet
            // 
            this._291_group2DataSet.DataSetName = "_291_group2DataSet";
            this._291_group2DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(497, 36);
            this.checkBox3.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(72, 20);
            this.checkBox3.TabIndex = 76;
            this.checkBox3.Text = "Admin";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // CCarType
            // 
            this.CCarType.FormattingEnabled = true;
            this.CCarType.Items.AddRange(new object[] {
            "Economy",
            "Compact",
            "Mid-Size",
            "Full-Size",
            "Luxury",
            "Compact SUV",
            "Full-size SUV",
            "Minivan",
            "Passenger Van",
            "Pick-up Truck"});
            this.CCarType.Location = new System.Drawing.Point(772, 369);
            this.CCarType.Margin = new System.Windows.Forms.Padding(2);
            this.CCarType.Name = "CCarType";
            this.CCarType.Size = new System.Drawing.Size(190, 24);
            this.CCarType.TabIndex = 68;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.SkyBlue;
            this.button5.Location = new System.Drawing.Point(743, 537);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(239, 73);
            this.button5.TabIndex = 23;
            this.button5.Text = "Delete Car";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.SkyBlue;
            this.button4.Location = new System.Drawing.Point(427, 537);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(239, 73);
            this.button4.TabIndex = 22;
            this.button4.Text = "Update Car";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // AddCar
            // 
            this.AddCar.BackColor = System.Drawing.Color.SkyBlue;
            this.AddCar.Location = new System.Drawing.Point(99, 537);
            this.AddCar.Margin = new System.Windows.Forms.Padding(4);
            this.AddCar.Name = "AddCar";
            this.AddCar.Size = new System.Drawing.Size(239, 73);
            this.AddCar.TabIndex = 21;
            this.AddCar.Text = "Add Car";
            this.AddCar.UseVisualStyleBackColor = false;
            this.AddCar.Click += new System.EventHandler(this.button3_Click);
            // 
            // CInsurance
            // 
            this.CInsurance.Location = new System.Drawing.Point(772, 435);
            this.CInsurance.Margin = new System.Windows.Forms.Padding(4);
            this.CInsurance.Name = "CInsurance";
            this.CInsurance.Size = new System.Drawing.Size(181, 22);
            this.CInsurance.TabIndex = 20;
            // 
            // Color
            // 
            this.Color.Location = new System.Drawing.Point(772, 293);
            this.Color.Margin = new System.Windows.Forms.Padding(4);
            this.Color.Name = "Color";
            this.Color.Size = new System.Drawing.Size(181, 22);
            this.Color.TabIndex = 18;
            // 
            // Odometer
            // 
            this.Odometer.Location = new System.Drawing.Point(772, 130);
            this.Odometer.Margin = new System.Windows.Forms.Padding(4);
            this.Odometer.Name = "Odometer";
            this.Odometer.Size = new System.Drawing.Size(181, 22);
            this.Odometer.TabIndex = 16;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(571, 432);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(146, 25);
            this.label36.TabIndex = 15;
            this.label36.Text = "Insurance No.";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(571, 365);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(102, 25);
            this.label35.TabIndex = 14;
            this.label35.Text = "Car Type";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(571, 291);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(64, 25);
            this.label34.TabIndex = 13;
            this.label34.Text = "Color";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(571, 208);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(107, 25);
            this.label33.TabIndex = 12;
            this.label33.Text = "Branch ID";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(571, 127);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(146, 25);
            this.label32.TabIndex = 11;
            this.label32.Text = "Odometer No.";
            // 
            // Seats
            // 
            this.Seats.Location = new System.Drawing.Point(293, 435);
            this.Seats.Margin = new System.Windows.Forms.Padding(4);
            this.Seats.Name = "Seats";
            this.Seats.Size = new System.Drawing.Size(181, 22);
            this.Seats.TabIndex = 10;
            // 
            // Year
            // 
            this.Year.Location = new System.Drawing.Point(293, 367);
            this.Year.Margin = new System.Windows.Forms.Padding(4);
            this.Year.Name = "Year";
            this.Year.Size = new System.Drawing.Size(181, 22);
            this.Year.TabIndex = 9;
            // 
            // Model
            // 
            this.Model.Location = new System.Drawing.Point(293, 293);
            this.Model.Margin = new System.Windows.Forms.Padding(4);
            this.Model.Name = "Model";
            this.Model.Size = new System.Drawing.Size(181, 22);
            this.Model.TabIndex = 8;
            // 
            // Make
            // 
            this.Make.Location = new System.Drawing.Point(293, 208);
            this.Make.Margin = new System.Windows.Forms.Padding(4);
            this.Make.Name = "Make";
            this.Make.Size = new System.Drawing.Size(181, 22);
            this.Make.TabIndex = 7;
            // 
            // VIN
            // 
            this.VIN.Location = new System.Drawing.Point(293, 130);
            this.VIN.Margin = new System.Windows.Forms.Padding(4);
            this.VIN.Name = "VIN";
            this.VIN.Size = new System.Drawing.Size(181, 22);
            this.VIN.TabIndex = 6;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(107, 432);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(131, 25);
            this.label31.TabIndex = 4;
            this.label31.Text = "No. of Seats";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(105, 291);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(71, 25);
            this.label30.TabIndex = 3;
            this.label30.Text = "Model";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(105, 365);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(57, 25);
            this.label28.TabIndex = 2;
            this.label28.Text = "Year";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(105, 208);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(65, 25);
            this.label26.TabIndex = 1;
            this.label26.Text = "Make";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(105, 127);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(48, 25);
            this.label22.TabIndex = 0;
            this.label22.Text = "VIN";
            // 
            // CarType
            // 
            this.CarType.BackColor = System.Drawing.Color.LightSkyBlue;
            this.CarType.Controls.Add(this.CTCarTypeID);
            this.CarType.Controls.Add(this.button6);
            this.CarType.Controls.Add(this.checkBox1);
            this.CarType.Controls.Add(this.label37);
            this.CarType.Controls.Add(this.label38);
            this.CarType.Controls.Add(this.label39);
            this.CarType.Controls.Add(this.label42);
            this.CarType.Controls.Add(this.button9);
            this.CarType.Controls.Add(this.DailyRate);
            this.CarType.Controls.Add(this.WeeklyRate);
            this.CarType.Controls.Add(this.MonthlyRate);
            this.CarType.Controls.Add(this.CTCarDescription);
            this.CarType.Controls.Add(this.label43);
            this.CarType.Controls.Add(this.label44);
            this.CarType.Controls.Add(this.label45);
            this.CarType.Controls.Add(this.label46);
            this.CarType.Controls.Add(this.label47);
            this.CarType.Location = new System.Drawing.Point(4, 25);
            this.CarType.Name = "CarType";
            this.CarType.Padding = new System.Windows.Forms.Padding(3);
            this.CarType.Size = new System.Drawing.Size(1051, 657);
            this.CarType.TabIndex = 4;
            this.CarType.Text = "Car Type";
            // 
            // CTCarTypeID
            // 
            this.CTCarTypeID.Location = new System.Drawing.Point(584, 124);
            this.CTCarTypeID.Name = "CTCarTypeID";
            this.CTCarTypeID.Size = new System.Drawing.Size(183, 22);
            this.CTCarTypeID.TabIndex = 77;
            this.CTCarTypeID.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.SlateGray;
            this.button6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button6.Location = new System.Drawing.Point(482, 238);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(125, 64);
            this.button6.TabIndex = 76;
            this.button6.Text = "Add Car Type";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(509, 34);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(72, 20);
            this.checkBox1.TabIndex = 75;
            this.checkBox1.Text = "Admin";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.Crimson;
            this.label37.Location = new System.Drawing.Point(766, 424);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(138, 25);
            this.label37.TabIndex = 71;
            this.label37.Text = "Monthly Rate";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.Crimson;
            this.label38.Location = new System.Drawing.Point(477, 423);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(134, 25);
            this.label38.TabIndex = 70;
            this.label38.Text = "Weekly Rate";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.Crimson;
            this.label39.Location = new System.Drawing.Point(773, 238);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(0, 25);
            this.label39.TabIndex = 69;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.Crimson;
            this.label42.Location = new System.Drawing.Point(185, 424);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(110, 25);
            this.label42.TabIndex = 66;
            this.label42.Text = "Daily Rate";
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.SlateGray;
            this.button9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button9.Location = new System.Drawing.Point(409, 519);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(262, 64);
            this.button9.TabIndex = 65;
            this.button9.Text = "Update Car Type Rate";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // DailyRate
            // 
            this.DailyRate.Location = new System.Drawing.Point(154, 451);
            this.DailyRate.Name = "DailyRate";
            this.DailyRate.Size = new System.Drawing.Size(189, 22);
            this.DailyRate.TabIndex = 64;
            // 
            // WeeklyRate
            // 
            this.WeeklyRate.Location = new System.Drawing.Point(452, 451);
            this.WeeklyRate.Name = "WeeklyRate";
            this.WeeklyRate.Size = new System.Drawing.Size(189, 22);
            this.WeeklyRate.TabIndex = 63;
            // 
            // MonthlyRate
            // 
            this.MonthlyRate.Location = new System.Drawing.Point(745, 451);
            this.MonthlyRate.Name = "MonthlyRate";
            this.MonthlyRate.Size = new System.Drawing.Size(189, 22);
            this.MonthlyRate.TabIndex = 62;
            // 
            // CTCarDescription
            // 
            this.CTCarDescription.FormattingEnabled = true;
            this.CTCarDescription.Location = new System.Drawing.Point(584, 177);
            this.CTCarDescription.Margin = new System.Windows.Forms.Padding(2);
            this.CTCarDescription.Name = "CTCarDescription";
            this.CTCarDescription.Size = new System.Drawing.Size(183, 24);
            this.CTCarDescription.TabIndex = 61;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(715, 196);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(0, 29);
            this.label43.TabIndex = 59;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(372, 124);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(129, 25);
            this.label44.TabIndex = 58;
            this.label44.Text = "Car Type ID";
            this.label44.Click += new System.EventHandler(this.label44_Click);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(340, 174);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(161, 25);
            this.label45.TabIndex = 57;
            this.label45.Text = "Car Description";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(757, 218);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(0, 20);
            this.label46.TabIndex = 56;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(463, 343);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(158, 29);
            this.label47.TabIndex = 55;
            this.label47.Text = "Update Rate";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Gainsboro;
            this.tabPage3.Controls.Add(this.checkBox4);
            this.tabPage3.Controls.Add(this.Report);
            this.tabPage3.Controls.Add(this.label52);
            this.tabPage3.Controls.Add(this.dateTimePicker2);
            this.tabPage3.Controls.Add(this.dateTimePicker1);
            this.tabPage3.Controls.Add(this.label51);
            this.tabPage3.Controls.Add(this.label50);
            this.tabPage3.Controls.Add(this.label49);
            this.tabPage3.Controls.Add(this.comboBox3);
            this.tabPage3.Controls.Add(this.chart1);
            this.tabPage3.Controls.Add(this.label48);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1051, 657);
            this.tabPage3.TabIndex = 5;
            this.tabPage3.Text = "Statistics";
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(508, 33);
            this.checkBox4.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(72, 20);
            this.checkBox4.TabIndex = 76;
            this.checkBox4.Text = "Admin";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // Report
            // 
            this.Report.BackColor = System.Drawing.Color.GreenYellow;
            this.Report.Location = new System.Drawing.Point(682, 423);
            this.Report.Name = "Report";
            this.Report.Size = new System.Drawing.Size(260, 86);
            this.Report.TabIndex = 9;
            this.Report.Text = "Generate Report";
            this.Report.UseVisualStyleBackColor = false;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(214, 282);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(169, 16);
            this.label52.TabIndex = 8;
            this.label52.Text = "Display Info Requested";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(728, 242);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker2.TabIndex = 7;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(728, 161);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker1.TabIndex = 6;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(609, 161);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(61, 25);
            this.label51.TabIndex = 5;
            this.label51.Text = "From";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(632, 240);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(38, 25);
            this.label50.TabIndex = 4;
            this.label50.Text = "To";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(734, 80);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(175, 32);
            this.label49.TabIndex = 3;
            this.label49.Text = "Date Range";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Most sales by branch",
            "Highest revenue by branch",
            "Color of car most rented",
            "Type of car most rented",
            "Customer with most rentals"});
            this.comboBox3.Location = new System.Drawing.Point(175, 161);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(250, 24);
            this.comboBox3.TabIndex = 2;
            // 
            // chart1
            // 
            chartArea7.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea7);
            legend7.Name = "Legend1";
            this.chart1.Legends.Add(legend7);
            this.chart1.Location = new System.Drawing.Point(99, 337);
            this.chart1.Name = "chart1";
            series7.ChartArea = "ChartArea1";
            series7.Legend = "Legend1";
            series7.Name = "Series1";
            this.chart1.Series.Add(series7);
            this.chart1.Size = new System.Drawing.Size(434, 269);
            this.chart1.TabIndex = 1;
            this.chart1.Text = "chart1";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(196, 101);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(210, 32);
            this.label48.TabIndex = 0;
            this.label48.Text = "Pick a statistic";
            // 
            // branchTableAdapter
            // 
            this.branchTableAdapter.ClearBeforeFill = true;
            // 
            // branchTableAdapter1
            // 
            this.branchTableAdapter1.ClearBeforeFill = true;
            // 
            // branchTableAdapter2
            // 
            this.branchTableAdapter2.ClearBeforeFill = true;
            // 
            // customerTableAdapter1
            // 
            this.customerTableAdapter1.ClearBeforeFill = true;
            // 
            // GetBranch
            // 
            this.GetBranch.Location = new System.Drawing.Point(247, 438);
            this.GetBranch.Name = "GetBranch";
            this.GetBranch.Size = new System.Drawing.Size(157, 31);
            this.GetBranch.TabIndex = 77;
            this.GetBranch.Text = "Get Branch";
            this.GetBranch.UseVisualStyleBackColor = true;
            this.GetBranch.Click += new System.EventHandler(this.GetBranch_Click);
            // 
            // PrevBranch
            // 
            this.PrevBranch.Location = new System.Drawing.Point(445, 438);
            this.PrevBranch.Name = "PrevBranch";
            this.PrevBranch.Size = new System.Drawing.Size(157, 31);
            this.PrevBranch.TabIndex = 77;
            this.PrevBranch.Text = "Prev Branch";
            this.PrevBranch.UseVisualStyleBackColor = true;
            this.PrevBranch.Click += new System.EventHandler(this.PrevBranch_Click);
            // 
            // NextBranch
            // 
            this.NextBranch.Location = new System.Drawing.Point(652, 438);
            this.NextBranch.Name = "NextBranch";
            this.NextBranch.Size = new System.Drawing.Size(157, 31);
            this.NextBranch.TabIndex = 77;
            this.NextBranch.Text = "Next Branch";
            this.NextBranch.UseVisualStyleBackColor = true;
            this.NextBranch.Click += new System.EventHandler(this.NextBranch_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1189, 712);
            this.Controls.Add(this.Customer);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Customer.ResumeLayout(false);
            this.Customers.ResumeLayout(false);
            this.Customers.PerformLayout();
            this.Branch.ResumeLayout(false);
            this.Branch.PerformLayout();
            this.DisplayButton.ResumeLayout(false);
            this.DisplayButton.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dropoffMinute)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dropoffHour)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pickupMinute)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pickupHour)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.branchBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._291_group2DataSet)).EndInit();
            this.CarType.ResumeLayout(false);
            this.CarType.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl Customer;
        private System.Windows.Forms.TabPage Customers;
        private System.Windows.Forms.Label FNameLabel;
        private System.Windows.Forms.TabPage Branch;
        private System.Windows.Forms.TabPage DisplayButton;
        private System.Windows.Forms.TextBox StreetAddress2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox StreetAddress1;
        private System.Windows.Forms.Label StreetAddressLabel1;
        private System.Windows.Forms.TextBox LName;
        private System.Windows.Forms.Label LNameLabel;
        private System.Windows.Forms.TextBox MName;
        private System.Windows.Forms.Label MNameLabel;
        private System.Windows.Forms.TextBox FName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox PostalCode;
        private System.Windows.Forms.Label PostalCodeLabel;
        private System.Windows.Forms.TextBox City;
        private System.Windows.Forms.Label CityLabel;
        private System.Windows.Forms.TextBox PhoneNumber;
        private System.Windows.Forms.Label PhoneLabel;
        private System.Windows.Forms.TextBox DriverLicense;
        private System.Windows.Forms.Label DriversLabel;
        private System.Windows.Forms.TextBox Insurance;
        private System.Windows.Forms.Label InsuranceLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button CreateCustomer;
        private System.Windows.Forms.Button UpdateCustomer;
        private System.Windows.Forms.DateTimePicker DOB;
        private System.Windows.Forms.RadioButton MembershipG;
        private System.Windows.Forms.RadioButton MembershipS;
        private System.Windows.Forms.TextBox BID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox BStreet_Address2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox BStreet_Address1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox BDescription;
        private System.Windows.Forms.Label DescriptionLabel;
        private System.Windows.Forms.Button DeleteCustomer;
        private System.Windows.Forms.TextBox CID;
        private System.Windows.Forms.Label CustomerIDLabel;
        private System.Windows.Forms.TextBox Province;
        private System.Windows.Forms.Label ProvinceLabel;
        private System.Windows.Forms.TextBox BCity;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox BPhoneNumber;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox BProvince;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox BPostalCode;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button DeleteBranch;
        private System.Windows.Forms.Button UpdateBranch;
        private System.Windows.Forms.Button CreateBranch;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox pickupbranchBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox TransactionID;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox dropoffbranchBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.DateTimePicker pickupDate;
        private System.Windows.Forms.NumericUpDown pickupMinute;
        private System.Windows.Forms.NumericUpDown pickupHour;
        private System.Windows.Forms.ComboBox pickupTimeAMPM;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.NumericUpDown dropoffMinute;
        private System.Windows.Forms.NumericUpDown dropoffHour;
        private System.Windows.Forms.DateTimePicker dropoffDate;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label displaypbranch;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label displayptime;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label displaypdate;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label displaydtime;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label displayddate;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label displaydbranch;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox dropoffTimeAMPM;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button AddCar;
        private System.Windows.Forms.TextBox CInsurance;
        private System.Windows.Forms.TextBox Color;
        private System.Windows.Forms.TextBox Odometer;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox Seats;
        private System.Windows.Forms.TextBox Year;
        private System.Windows.Forms.TextBox Model;
        private System.Windows.Forms.TextBox Make;
        private System.Windows.Forms.TextBox VIN;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TabPage CarType;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TextBox DailyRate;
        private System.Windows.Forms.TextBox WeeklyRate;
        private System.Windows.Forms.TextBox MonthlyRate;
        private System.Windows.Forms.ComboBox CTCarDescription;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button Report;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.ComboBox CCarType;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.TextBox CTCarTypeID;
        private System.Windows.Forms.ComboBox CBID;
        private _291_group2DataSet _291_group2DataSet;
        private System.Windows.Forms.BindingSource branchBindingSource;
        private _291_group2DataSetTableAdapters.BranchTableAdapter branchTableAdapter;
        private _291_group2DataSetTableAdapters.BranchTableAdapter branchTableAdapter1;
        private System.Windows.Forms.Button PrevCustomer;
        private System.Windows.Forms.Button NextCustomer;
        private System.Windows.Forms.Button GetCustomer;
        private _291_group2DataSetTableAdapters.BranchTableAdapter branchTableAdapter2;
        private _291_group2DataSetTableAdapters.CustomerTableAdapter customerTableAdapter1;
        private System.Windows.Forms.Button NextBranch;
        private System.Windows.Forms.Button PrevBranch;
        private System.Windows.Forms.Button GetBranch;
    }
}

